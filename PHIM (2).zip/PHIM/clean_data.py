import pandas as pd

# Đọc dữ liệu từ file CSV
df = pd.read_csv('newFileCrudData.csv')

# Kiểm tra tên các cột có trong DataFrame
print("Tên các cột trong DataFrame:")
print(df.columns)

# Kiểm tra dữ liệu gốc
print(df['Ngày phát hành'].head())

# Chuyển đổi cột ngày tháng
df['Ngày phát hành'] = pd.to_datetime(df['Ngày phát hành'], errors='coerce', dayfirst=False)

# Chuyển đổi lại cột 'Ngày phát hành' về định dạng dd/mm/yyyy
df['Ngày phát hành'] = df['Ngày phát hành'].dt.strftime('%d/%m/%Y')

# Kiểm tra lại dữ liệu sau khi chuyển đổi
print(df['Ngày phát hành'].head())

# Thay thế NaN bằng giá trị 0
df['Doanh thu'] = pd.to_numeric(df['Doanh thu'], errors='coerce').fillna(0)
df['Ngân sách'] = pd.to_numeric(df['Ngân sách'], errors='coerce').fillna(0)
df['Điều chỉnh doanh thu'] = pd.to_numeric(df['Điều chỉnh doanh thu'], errors='coerce').fillna(0)
df['Điều chỉnh ngân sách'] = pd.to_numeric(df['Điều chỉnh ngân sách'], errors='coerce').fillna(0)

# Chuyển đổi các cột số thành định dạng có dấu phân cách hàng nghìn
df['Doanh thu'] = df['Doanh thu'].apply(lambda x: "{:,.0f}".format(x))
df['Ngân sách'] = df['Ngân sách'].apply(lambda x: "{:,.0f}".format(x))
df['Điều chỉnh doanh thu'] = df['Điều chỉnh doanh thu'].apply(lambda x: "{:,.0f}".format(x))
df['Điều chỉnh ngân sách'] = df['Điều chỉnh ngân sách'].apply(lambda x: "{:,.0f}".format(x))

# Sử dụng f-string để định dạng số với 2 chữ số sau dấu phẩy
df['Mức độ phổ biến'] = df['Mức độ phổ biến'].apply(lambda x: f"{x:.2f}")

print(df['Doanh thu'].head())
print(df['Mức độ phổ biến'].head())

# Kiểm tra xem cột "Từ khoá" và "Khẩu hiệu" có tồn tại không
if 'Từ khoá' in df.columns:
    df['Từ khoá'].fillna(df['Tiêu đề gốc'], inplace=True)
else:
    print("Cột 'Từ khoá' không tồn tại trong DataFrame.")

if 'Khẩu hiệu' in df.columns:
    df['Khẩu hiệu'].fillna(df['Tiêu đề gốc'], inplace=True)
else:
    print("Cột 'Khẩu hiệu' không tồn tại trong DataFrame.")

# Loại bỏ dữ liệu bị NaN ở những cột còn lại
df = df.dropna()

# Lưu lại vào file CSV
df.to_csv('newFileCleanData.csv', index=False)

print("File newFileCleanData.csv đã được tạo.")
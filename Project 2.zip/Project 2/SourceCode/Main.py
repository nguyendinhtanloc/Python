import CleanData
import NewData
import CRUDData
import GUI
import Matplotlib
def main():
    # Lọc dữ liệu (Class CleanData)
    CleanData.CleanData

    # Phát sinh thêm dữ liệu sau khi lọc (NewData)
    NewData.NewData

    CRUDData.CRUDData

    Matplotlib.main()
    
    # GUI.main()


if __name__ == "__main__":
    main()

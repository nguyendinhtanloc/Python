from tkinter import *
from tkinter.ttk import Treeview, Scrollbar

# Tạo cửa sổ chính
window = Tk()
window.title("Dữ liệu phim")
window.geometry("800x600")

# Tạo một Treeview
tree = Treeview(window, columns=("A", "B", "C"), show="headings")
tree.heading("A", text="Cột A")
tree.heading("B", text="Cột B")
tree.heading("C", text="Cột C")

# Chèn một số dữ liệu vào Treeview
for i in range(1, 101):
    tree.insert("", "end", values=(f"Data {i}", f"Info {i}", f"More {i}"))

# Thanh cuộn dọc
v_scroll = Scrollbar(window, orient=VERTICAL, command=tree.yview)
tree.configure(yscrollcommand=v_scroll.set)
v_scroll.pack(side=RIGHT, fill=Y)

# Thanh cuộn ngang
h_scroll = Scrollbar(window, orient=HORIZONTAL, command=tree.xview)
tree.configure(xscrollcommand=h_scroll.set)
h_scroll.pack(side=BOTTOM, fill=X)

tree.pack(fill=BOTH, expand=True)

# Hàm điều chỉnh thanh cuộn tự động (ví dụ: cuộn đến cuối)
def auto_scroll_to_end():
    tree.yview_moveto(1.0)  # Di chuyển thanh cuộn dọc đến cuối
    tree.xview_moveto(1.0)  # Di chuyển thanh cuộn ngang đến cuối

# Gọi hàm cuộn tự động sau khi thêm dữ liệu
auto_scroll_to_end()

# Chạy ứng dụng Tkinter
window.mainloop()

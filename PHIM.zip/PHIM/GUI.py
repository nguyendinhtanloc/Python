from tkinter import *
from tkinter.ttk import Combobox, Treeview, Notebook
from tkinter import ttk
import pandas as pd
import time
import math 
# Đọc dữ liệu từ file CSV
df = pd.read_csv('data.csv')

def my_function():
    # Đoạn mã bạn muốn tính thời gian chạy
    time.sleep(2)  # Giả sử chương trình mất 2 giây để thực hiện

# Ghi lại thời gian bắt đầu
start_time = time.time()

def search_data(column, value, data):
    if column == "Tất cả" or value == "Tất cả":
        df_filtered = data
    elif column and value:
        df_filtered = data[data[column].astype(str).str.contains(value, case=False, na=False)]
    elif column:
        df_filtered = data[[column]]
    else:
        df_filtered = data
    return df_filtered

def sort_data(column, data, reverse=False):
    if column:
        df_sorted = data.sort_values(by=column, ascending=not reverse)
        return df_sorted
    return data

def locDuLieu():
    df_new = pd.read_csv('newFileCleanData.csv')
    xemDuLieu(df_new)

# Hàm phân trang
def paginate_data(data, page, rows_per_page=50):
    total_rows = len(data)
    total_pages = math.ceil(total_rows / rows_per_page)
    start_idx = (page - 1) * rows_per_page
    end_idx = start_idx + rows_per_page
    paginated_data = data.iloc[start_idx:end_idx]
    return paginated_data, total_pages

# Định nghĩa các hàm cho các nút
def xemDuLieu(dataframe=df):
    new_window = Toplevel(window)
    new_window.title("Xem dữ liệu trước khi lọc")
    new_window.attributes('-fullscreen', True)
    new_window.config(bg="#f0f8ff")  # Background color for the new window

    label_title = Label(new_window, text="Dữ liệu phim từ năm", font=("Arial", 18, 'bold'), bg="#f0f8ff", fg="#333333")
    label_title.pack(pady=20)

    # Tabs cho nội dung
    notebook = Notebook(new_window)
    notebook.pack(fill=BOTH, expand=True, pady=10)

    # Tạo tab dữ liệu chính
    tab_data = Frame(notebook, bg="#e6f7ff")
    notebook.add(tab_data, text="Dữ liệu")

    frame_new_buttons = Frame(tab_data, bg="#e6f7ff")
    frame_new_buttons.pack(pady=10)

    label_column = Label(frame_new_buttons, text="Chọn cột:", bg="#e6f7ff", font=("Arial", 12))
    label_column.grid(row=0, column=0, padx=10, pady=10)

    combo_columns = Combobox(frame_new_buttons, values=["Tất cả"] + list(dataframe.columns), font=("Arial", 12))
    combo_columns.grid(row=0, column=1, padx=10, pady=10)

    label_value = Label(frame_new_buttons, text="Nhập giá trị:", bg="#e6f7ff", font=("Arial", 12))
    label_value.grid(row=0, column=2, padx=10, pady=10)

    combo_values = Combobox(frame_new_buttons, font=("Arial", 12))
    combo_values.grid(row=0, column=3, padx=10, pady=10)

    def update_values(event):
        column = combo_columns.get()
        if column and column != "Tất cả":
            unique_values = dataframe[column].dropna().unique().tolist()
            combo_values['values'] = ["Tất cả"] + unique_values
        else:
            combo_values['values'] = ["Tất cả"]

    combo_columns.bind("<<ComboboxSelected>>", update_values)
    
    # Biến để lưu trữ dữ liệu hiện tại và trang hiện tại
    current_data = dataframe
    current_page = 1

    # Frame chứa nội dung dữ liệu
    frame_new_content = Frame(tab_data, bg="#e6f7ff")
    frame_new_content.pack(fill=BOTH, expand=True)

    # Treeview với thanh cuộn ngang và dọc
    tree = Treeview(frame_new_content, columns=list(dataframe.columns), show="headings")
    for col in dataframe.columns:
        tree.heading(col, text=col)
        tree.column(col, width=150, anchor=CENTER)

    # Thanh cuộn ngang
    scroll_x = Scrollbar(frame_new_content, orient=HORIZONTAL, command=tree.xview)
    scroll_x.pack(side=BOTTOM, fill=X)
    tree.configure(xscrollcommand=scroll_x.set)

    # Thanh cuộn dọc
    scroll_y = Scrollbar(frame_new_content, orient=VERTICAL, command=tree.yview)
    scroll_y.pack(side=RIGHT, fill=Y)
    tree.configure(yscrollcommand=scroll_y.set)

    tree.pack(side=LEFT, fill=BOTH, expand=True)
    
    # Frame chứa nút điều hướng trang
    frame_pagination = Frame(tab_data)
    frame_pagination.pack(pady=10)

    label_page = Label(frame_pagination, text="")
    label_page.pack()

    def update_page_label(current_page, total_pages):
        label_page.config(text=f"Trang {current_page}/{total_pages}")

    def load_data(data):
        tree.delete(*tree.get_children())
        for index, row in data.iterrows():
            tree.insert("", "end", values=list(row))

    def change_page(direction):
        nonlocal current_page, current_data
        paginated_data, total_pages = paginate_data(current_data, current_page + direction)
        
        if 1 <= current_page + direction <= total_pages:
            current_page += direction
            load_data(paginated_data)
            update_page_label(current_page, total_pages)

    btn_prev = Button(frame_pagination, text="Trang trước", command=lambda: change_page(-1))
    btn_prev.pack(side=LEFT, padx=5)

    btn_next = Button(frame_pagination, text="Trang tiếp", command=lambda: change_page(1))
    btn_next.pack(side=LEFT, padx=5)
    
    def search_and_paginate():
        nonlocal current_data, current_page
        current_data = search_data(combo_columns.get(), combo_values.get(), dataframe)
        current_page = 1
        paginated_data, total_pages = paginate_data(current_data, current_page)
        load_data(paginated_data)
        update_page_label(current_page, total_pages)

    def sort_and_paginate(column, reverse=False):
        nonlocal current_data, current_page
        current_data = sort_data(column, current_data, reverse)
        current_page = 1
        paginated_data, total_pages = paginate_data(current_data, current_page)
        load_data(paginated_data)
        update_page_label(current_page, total_pages)

    button_search_new = Button(frame_new_buttons, text="Tìm kiếm", command=lambda: load_data(search_data(combo_columns.get(), combo_values.get(), dataframe)), font=("Arial", 12), bg="#4CAF50", fg="white", relief="raised")
    button_search_new.grid(row=0, column=4, padx=10, pady=10)
    
    button_search_new = Button(frame_new_buttons, text="Tìm kiếm", command=search_and_paginate,  font=("Arial", 12), bg="#4CAF50", fg="white", relief="raised")
    button_search_new.grid(row=0, column=4, padx=10, pady=10)

    label_sort = Label(frame_new_buttons, text="Sắp xếp theo:")
    label_sort.grid(row=0, column=5, padx=10, pady=10)

    combo_sort = Combobox(frame_new_buttons, values=list(dataframe.columns))
    combo_sort.grid(row=0, column=6, padx=10, pady=10)

    button_sort_az = Button(frame_new_buttons, text="Sắp xếp tăng", command=lambda: sort_and_paginate(combo_sort.get(), False), font=("Arial", 12), bg="#2196F3", fg="white", relief="raised")
    button_sort_az.grid(row=0, column=7, padx=10, pady=10)

    button_sort_za = Button(frame_new_buttons, text="Sắp xếp giảm", command=lambda: sort_and_paginate(combo_sort.get(), True), font=("Arial", 12), bg="#FF5722", fg="white", relief="raised")
    button_sort_za.grid(row=0, column=8, padx=10, pady=10)

    # Tải dữ liệu ban đầu với phân trang
    initial_data, total_pages = paginate_data(dataframe, current_page)
    load_data(initial_data)
    update_page_label(current_page, total_pages)

    # Tab phụ (ví dụ: thống kê)
    tab_stats = Frame(notebook, bg="#f0f8ff")
    notebook.add(tab_stats, text="Thống kê")

    label_stats = Label(tab_stats, text="Thống kê dữ liệu (ví dụ: tổng số phim, doanh thu trung bình)", font=("Arial", 12), bg="#f0f8ff")
    label_stats.pack(pady=10)

    total_movies = len(dataframe)
    avg_revenue = dataframe["revenue"].mean() if "revenue" in dataframe.columns else 0

    stats_text = f"Tổng số phim: {total_movies}\nDoanh thu trung bình: {avg_revenue:.2f}"
    label_stats_data = Label(tab_stats, text=stats_text, font=("Arial", 12), bg="#f0f8ff")
    label_stats_data.pack(pady=10)

    button_back_new = Button(new_window, text="Quay lại", command=new_window.destroy, font=("Arial", 14), bg="#FF5733", fg="white", relief="raised")
    button_back_new.pack(pady=10)

# Tạo cửa sổ chính
# Gọi hàm hoặc thực hiện đoạn mã bạn muốn đo
my_function()

window = Tk()
window.title("Dữ liệu phim nước ngoài từ năm")
window.geometry("1366x768")
window.config(bg="#f0f8ff")

label_title = Label(window, text="Dữ liệu phim nước ngoài từ năm 1966 - 2015", font=("Arial", 18, 'bold'), bg="#f0f8ff", fg="#333333")
label_title.pack(pady=20)

frame_buttons = Frame(window, bg="#f0f8ff")
frame_buttons.pack(pady=10)

# Gọi hàm xem dữ liệu
button_view = Button(frame_buttons, text="Xem dữ liệu", width=12, height=2, command=lambda: xemDuLieu(df), font=("Arial", 12), bg="#4CAF50", fg="white", relief="raised")
button_view.grid(row=1, column=0, padx=5, pady=5)

button_filter = Button(frame_buttons, text="Lọc dữ liệu", width=12, height=2, command=locDuLieu, font=("Arial", 12), bg="#FF5722", fg="white", relief="raised")
button_filter.grid(row=1, column=1, padx=5, pady=5)

button_crud = Button(frame_buttons, text="CRUD", width=12, height=2, font=("Arial", 12), bg="#2196F3", fg="white", relief="raised")
button_crud.grid(row=1, column=2, padx=5, pady=5)

button_analyze = Button(frame_buttons, text="Phân tích", width=12, height=2, font=("Arial", 12), bg="#9C27B0", fg="white", relief="raised")
button_analyze.grid(row=1, column=3, padx=5, pady=5)

frame_content = Frame(window, bg="#f0f8ff")
frame_content.pack(pady=10)

label_image = Label(frame_content, text="Hình ảnh", borderwidth=2, relief="solid", width=20, height=10, bg="#e6f7ff")
label_image.grid(row=0, column=0, padx=10, pady=10)

label_content = Label(frame_content, text="Nội dung", borderwidth=2, relief="solid", width=40, height=10, bg="#e6f7ff")
label_content.grid(row=0, column=1, padx=10, pady=10)

button_back = Button(window, text="Thoát", command=quit, font=("Arial", 14), bg="#FF5733", fg="white", relief="raised")
button_back.pack(pady=20)

# Chạy ứng dụng Tkinter
window.mainloop()

# Ghi lại thời gian kết thúc
end_time = time.time()

# Tính thời gian chạy
execution_time = end_time - start_time

# In ra thời gian chạy (đơn vị giây)
print(f"Thời gian chạy của chương trình là: {execution_time} giây")
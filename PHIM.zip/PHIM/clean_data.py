import pandas as pd
import numpy as np
from datetime import datetime
import random
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

# Hàm đọc dữ liệu từ file CSV
def read_data(file_path):
    return pd.read_csv(file_path)

# Hàm kiểm tra và chuyển đổi cột 'Ngày phát hành'
def process_release_date(df):
    df['Ngày phát hành'] = pd.to_datetime(df['Ngày phát hành'], errors='coerce', dayfirst=False)
    df['Ngày phát hành'] = df['Ngày phát hành'].dt.strftime('%d/%m/%Y')
    return df

# Hàm xử lý dữ liệu cột số (Doanh thu, Ngân sách, Điều chỉnh doanh thu, Điều chỉnh ngân sách)
def process_numeric_columns(df):
    df['Doanh thu'] = pd.to_numeric(df['Doanh thu'], errors='coerce').fillna(0)
    df['Ngân sách'] = pd.to_numeric(df['Ngân sách'], errors='coerce').fillna(0)
    return df

# Hàm chuyển đổi cột số thành định dạng có dấu phân cách hàng nghìn
def format_numeric_columns(df):
    df['Doanh thu'] = df['Doanh thu'].apply(lambda x: "{:,.0f}".format(x))
    df['Ngân sách'] = df['Ngân sách'].apply(lambda x: "{:,.0f}".format(x))
    df['Chênh lệch giữa ngân sách và doanh thu'] = df['Chênh lệch giữa ngân sách và doanh thu'].apply(lambda x: "{:,.0f}".format(x))
    return df

# Hàm xử lý cột 'Mức độ phổ biến' (chuyển đổi thành số thực và chỉ lấy 2 số sau dấu phẩy)
def process_popularity(df):
    df['Mức độ phổ biến'] = pd.to_numeric(df['Mức độ phổ biến'], errors='coerce')
    df['Mức độ phổ biến'] = df['Mức độ phổ biến'].apply(lambda x: round(x, 2) if pd.notna(x) else 0.0)  # Giới hạn 2 chữ số thập phân
    return df

# Hàm xử lý cột 'Từ khoá' và 'Khẩu hiệu'
def fill_missing_keywords_and_slogans(df):
    if 'Từ khoá' in df.columns:
        df['Từ khoá'].fillna(df['Tiêu đề gốc'], inplace=True)
    if 'Khẩu hiệu' in df.columns:
        df['Khẩu hiệu'].fillna(df['Tiêu đề gốc'], inplace=True)
    return df

# Hàm xử lý ngày phát hành trống
def fill_missing_dates(df):
    def generate_random_date(row):
        if pd.isna(row['Ngày phát hành']) and not pd.isna(row['Năm công chiếu']):  # Nếu ngày phát hành trống và có năm công chiếu
            year = int(row['Năm công chiếu'])
            month = random.randint(1, 12)
            day = random.randint(1, 28)
            return datetime(year, month, day).strftime('%d/%m/%Y')
        return row['Ngày phát hành']

    df['Ngày phát hành'] = df.apply(generate_random_date, axis=1)
    return df

# Hàm loại bỏ các dòng có giá trị NaN trong các cột
def drop_na_values(df):
    return df.dropna()

# Hàm xử lý ngân sách bằng cách thay thế giá trị trống hoặc bằng 0 bằng giá trị trung bình
def handle_missing_budget(df):
    # Tính giá trị trung bình của ngân sách (bỏ qua các giá trị bằng 0)
    median_budget = df['Ngân sách'][df['Ngân sách'] > 0].median()
    
    # Thay thế giá trị 0 và NaN bằng giá trị trung bình
    df['Ngân sách'].replace(0, median_budget, inplace=True)
    df['Ngân sách'].fillna(median_budget, inplace=True)
    
    return df

# Hàm thay đổi "Mức độ phổ biến" nếu nằm trong khoảng từ 0.0 đến 10
def change_popularity(row):
    try:
        popularity = float(row['Mức độ phổ biến'])
    except ValueError:
        # Nếu giá trị không thể chuyển đổi, giữ nguyên giá trị ban đầu
        popularity = 0.0

    # Kiểm tra nếu "Mức độ phổ biến" nằm trong khoảng từ 0.0 đến 10
    if 0.0 <= popularity <= 10:
        # Thay đổi giá trị "Mức độ phổ biến" bằng một giá trị ngẫu nhiên từ 10 đến 20
        row['Mức độ phổ biến'] = round(random.uniform(20, 40), 2)  # Giới hạn 2 chữ số thập phân
    return row

# Hàm áp dụng thay đổi "Mức độ phổ biến" cho toàn bộ DataFrame
def apply_popularity_change(df):
    df = df.apply(change_popularity, axis=1)
    return df

# Hàm cập nhật doanh thu dựa trên mức độ phổ biến (0.01 mức độ = 1 triệu đô)
def update_revenue(df):
    # Cập nhật doanh thu từ Mức độ phổ biến (giả sử 0.01 mức độ = 1 triệu đô)
    df['Doanh thu'] = df['Mức độ phổ biến'] * 10000000
    return df

# Hàm tạo cột chênh lệch giữa ngân sách và doanh thu
# Hàm tạo cột chênh lệch giữa ngân sách và doanh thu và di chuyển nó bên cạnh 'Doanh thu'
def add_budget_revenue_difference(df):
    # Tạo cột 'Chênh lệch giữa ngân sách và doanh thu'
    df['Chênh lệch giữa ngân sách và doanh thu'] = df['Doanh thu'] - df['Ngân sách']
    # Đưa cột 'Chênh lệch giữa ngân sách và doanh thu' ngay sau cột 'Doanh thu'
    cols = df.columns.tolist()  # Lấy danh sách các cột hiện tại
    idx_doanh_thu = cols.index('Doanh thu')  # Lấy vị trí của cột 'Doanh thu'
    # Cập nhật lại thứ tự cột trong DataFrame
    df = df[cols]
    
    return df


# Hàm xóa các cột "Điều chỉnh doanh thu" và "Điều chỉnh ngân sách"
def remove_adjustment_columns(df):
    df.drop(columns=['Điều chỉnh doanh thu', 'Điều chỉnh ngân sách'], inplace=True)
    return df

# Hàm điều chỉnh Thời lượng phim nếu trong khoảng từ 0 đến 45
def adjust_movie_runtime(df):
    median_runtime = df['Thời lượng phát sóng'].median()  # Lấy giá trị trung vị của Thời gian
    df['Thời lượng phát sóng'] = df['Thời lượng phát sóng'].apply(lambda x: random.randint(int(median_runtime - 10), int(median_runtime + 10)) if 0 <= x <= 45 else x)
    return df

# Hàm lưu dữ liệu vào file CSV
def save_to_csv(df, file_path):
    df.to_csv(file_path, index=False)
    print(f"File {file_path} đã được tạo.")

# Main function to call all tasks
def main():
    # Đọc dữ liệu
    df = pd.read_csv('newFileCrudData.csv')

    # Kiểm tra tên các cột
    print("Tên các cột trong DataFrame:")
    print(df.columns)

    # Xử lý ngày phát hành
    df = process_release_date(df)

    # Xử lý các cột số
    df = process_numeric_columns(df)

    # Xử lý cột 'Mức độ phổ biến'
    df = process_popularity(df)

    # Xử lý cột 'Từ khoá' và 'Khẩu hiệu'
    df = fill_missing_keywords_and_slogans(df)

    # Xử lý ngày phát hành trống
    df = fill_missing_dates(df)

    # Xử lý ngân sách bằng cách thay thế giá trị trống hoặc bằng 0 bằng ngân sách trung bình
    df = handle_missing_budget(df)

    # Thay đổi "Mức độ phổ biến" và cập nhật doanh thu
    df = apply_popularity_change(df)
    df = update_revenue(df)

    # Tạo cột chênh lệch giữa ngân sách và doanh thu và di chuyển nó bên cạnh 'Doanh thu'
    df = add_budget_revenue_difference(df)

    # Xóa các cột điều chỉnh doanh thu và ngân sách
    df = remove_adjustment_columns(df)

    # Điều chỉnh Thời lượng phim nếu giá trị trong khoảng từ 0 đến 45
    df = adjust_movie_runtime(df)

    # Chuyển đổi các cột số thành định dạng có dấu phân cách hàng nghìn
    df = format_numeric_columns(df)
    
    # Loại bỏ NaN ở các cột khác
    df = drop_na_values(df)

    # Kiểm tra NaN trong các cột
    print("Số lượng NaN trong từng cột:")
    print(df.isna().sum())

    # Kiểm tra giá trị 0 trong các cột
    print("\nSố lượng giá trị bằng 0 trong từng cột:")
    print((df == 0).sum())

    # Lưu dữ liệu vào file mới
    save_to_csv(df, 'newFileCleanData.csv')

# Gọi hàm main để chạy chương trình
if __name__ == "__main__":
    main()